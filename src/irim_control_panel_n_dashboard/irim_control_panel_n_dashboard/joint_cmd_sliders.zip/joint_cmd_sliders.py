#!/usr/bin/env python3

import rclpy
from rclpy.node import Node
from std_msgs.msg import Float64MultiArray

from PyQt5 import QtWidgets, QtCore
import sys
from functools import partial


# Arm 관련된 데이터는 아직 아무것도 제대로 된게 없음.

# Thumb:  CMC yaw, CMC roll, MCP
# Index:  ab/ad, MCP flex/ext, PIP flex/ext
# Middle: ab/ad, MCP flex/ext, PIP flex/ext
# Ring:   ab/ad, MCP flex/ext, PIP flex/ext
# Little: ab/ad, MCP flex/ext, PIP flex/ext

# 부호!!!!
# Thumb: Retroposition이 +, Flexion이 +, Flexion이 +
# Index 기준 Adduction 이 + 방향. Flexion이 +, Flexion이 +
# addcution은 middle 기준 좌우 대칭이지만, 4개의 손가락 모두 index와 같은 부호로 움직임.




# -- Global configuration --
NAMES = [
    'Arm_R',
    'Hand_R_thumb_wir',
    'Hand_R_index_wir',
    'Hand_R_middle_wir',
    'Hand_R_ring_wir',
    'Hand_R_little_wir'
]
NUM_JOINTS = [7, 3, 3, 3, 3, 3]
SLIDER_STEPS = 1000

SLIDER_MINS = [
    [-1.0, -0.8, -1.0, -0.5, -0.3, -0.7, -1.0],
    [-2.617994,       0.0, 0.0],
    [-0.5,      -0.174532, 0.0],
    [-0.5,      -0.174532, 0.0],
    [-0.5,      -0.174532, 0.0],
    [-0.5,      -0.174532, 0.0]
]
SLIDER_MAXS = [
    [ 1.0,  0.8,  1.0,  0.5,  0.3,  0.7,  1.0],
    [ 0.0,  1.570796,  1.570796],
    [ 0.5,  1.570796,  1.7453293],
    [ 0.5,  1.570796,  1.7453293],
    [ 0.5,  1.570796,  1.7453293],
    [ 0.5,  1.570796,  1.7453293]
]

class JointCommandPublisherNode(Node):
    def __init__(self):
        super().__init__('joint_command_publisher')
        self._publishers_map = {}
        for name in NAMES:
            topic = f'/robot_inbound/{name}/joint_command'
            pub = self.create_publisher(Float64MultiArray, topic, 10)
            self._publishers_map[name] = pub
            self.get_logger().info(f'Created publisher for {topic}')

    def publish(self, name, data):
        msg = Float64MultiArray()
        msg.data = data
        publisher = self._publishers_map.get(name)
        if publisher:
            publisher.publish(msg)
        else:
            self.get_logger().error(f'No publisher for {name}')

class MainWindow(QtWidgets.QWidget):
    def __init__(self, node):
        super().__init__()
        self.node = node
        self.setWindowTitle('Joint Command Publisher')
        self.layout = QtWidgets.QVBoxLayout()
        self.sliders = {}         # name → [QSlider,…]
        self.current_labels = {}  # name → [QLabel(current),…]

        self._init_ui()
        self.setLayout(self.layout)

        # ROS spin timer
        self.spin_timer = QtCore.QTimer()
        self.spin_timer.timeout.connect(self._ros_spin)
        self.spin_timer.start(1)

        # publish at 100Hz
        self.publish_timer = QtCore.QTimer()
        self.publish_timer.timeout.connect(self._publish_all)
        self.publish_timer.start(10)

    def _init_ui(self):
        for idx, name in enumerate(NAMES):
            group = QtWidgets.QGroupBox(name)
            v_layout = QtWidgets.QVBoxLayout()

            sliders_list = []
            labels_list = []

            for j in range(NUM_JOINTS[idx]):
                h_layout = QtWidgets.QHBoxLayout()

                # 최소/최대 레이블
                min_label = QtWidgets.QLabel(f"{SLIDER_MINS[idx][j]:.2f}")
                max_label = QtWidgets.QLabel(f"{SLIDER_MAXS[idx][j]:.2f}")

                # 슬라이더 생성
                slider = QtWidgets.QSlider(QtCore.Qt.Horizontal)
                slider.setMinimum(0)
                slider.setMaximum(SLIDER_STEPS)

                # 초기 위치를 항상 0 값에 대응하도록 설정
                minv = SLIDER_MINS[idx][j]
                maxv = SLIDER_MAXS[idx][j]
                # 0이 범위 내에 없다면 중간값 사용
                if minv <= 0 <= maxv:
                    zero_ratio = (0 - minv) / (maxv - minv)
                    init_val = int(zero_ratio * SLIDER_STEPS)
                else:
                    init_val = SLIDER_STEPS // 2
                slider.setValue(init_val)

                # 현재 값 레이블
                current_val = self._compute_value(idx, j, init_val)
                current_label = QtWidgets.QLabel(f"{current_val:.2f}")

                # layout 배치
                h_layout.addWidget(min_label)
                h_layout.addWidget(slider, stretch=1)
                h_layout.addWidget(current_label)
                h_layout.addWidget(max_label)

                # slider 변화 시 레이블 업데이트
                slider.valueChanged.connect(
                    partial(self._on_slider_change, idx, j, current_label)
                )

                v_layout.addLayout(h_layout)
                sliders_list.append(slider)
                labels_list.append(current_label)

            group.setLayout(v_layout)
            self.layout.addWidget(group)

            self.sliders[name] = sliders_list
            self.current_labels[name] = labels_list

    def _compute_value(self, idx, j, slider_value):
        """슬라이더 값 → 실제 관절 값 계산"""
        ratio = slider_value / SLIDER_STEPS
        minv = SLIDER_MINS[idx][j]
        maxv = SLIDER_MAXS[idx][j]
        return minv + ratio * (maxv - minv)

    def _on_slider_change(self, idx, j, label, slider_value):
        """슬라이더가 움직일 때 레이블 업데이트"""
        val = self._compute_value(idx, j, slider_value)
        label.setText(f"{val:.2f}")

    def _publish_all(self):
        for idx, name in enumerate(NAMES):
            data = []
            for j, slider in enumerate(self.sliders[name]):
                data.append(self._compute_value(idx, j, slider.value()))
            self.node.publish(name, data)

    def _ros_spin(self):
        rclpy.spin_once(self.node, timeout_sec=0)


def main():
    rclpy.init()
    node = JointCommandPublisherNode()

    app = QtWidgets.QApplication(sys.argv)
    window = MainWindow(node)
    window.show()

    exit_code = app.exec_()
    node.destroy_node()
    rclpy.shutdown()
    sys.exit(exit_code)

if __name__ == '__main__':
    main()
